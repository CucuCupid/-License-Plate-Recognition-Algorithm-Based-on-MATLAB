function varargout = gui(varargin)
% GUI MATLAB code for gui.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui

% Last Modified by GUIDE v2.5 20-Jun-2023 10:36:59

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @gui_OpeningFcn, ...
    'gui_OutputFcn',  @gui_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui is made visible.
function gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui (see VARARGIN)

% Choose default command line output for gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Code;
global tot;
tot=0;

pn='C:\Users\45094\Desktop\Chepai\pai\';
namelist = dir(strcat(pn,'*.jpg'));  %获得文件夹下所有的 .jpg图片
len = length(namelist);%当前文件的图片个数
for pi=1:len
    name=namelist(pi).name; %输入原始图像
    a=imread([pn name]);%输入原始图像
    if pi~=1
        clearvars Yfill_point Xfill_point a1 A1 ans blue BluePD BluePD_0  bottom_black_image  changave  changsum  ck_31818  close_ck_31818  Code  compare_blue  compare_fushi_blue  find_all  find_ck31818  find_fushi_blue  find_leftblack  find_rightblack  find_var  findc  findword_0  fname  fushi_blue  g_max  g_min  green  guolv_image  hang  i  I  I1  I2  I3  I4  I5  ifind  ifind_1  ifindsiz  ifindx  ihang  ii  ilie  Imagine  jiangesiz  jiequduan  jiequduansiz  jiequduansiz10_1  k2  kmax  kmin  kuan  kuangPD  l  left_word1  liccode  lie  MaxA1  mess_point         clearvars qidian qiechu_erzhi qiechu_image qiege_erzhi red right_word1 SamBw2 san_er san_yi score se SegBw2 siz siz_find_all suitble_area t T tongji_31818 tongji_compare_fs tongji_var Tongjisiz top_black_image white_image word1 word1_12 word1_14siz word1_siz word1PD word2 word3 word4 word5 word6 word7 word_ word_size X_dingwei_image X_dingwei_jihe Xb_qiechu XBluePDsize Xe_qiechu xiaodian Xqiechu_size Xqiechu_size_3_100 Yb_qiechu Ybiaoji YBluePDsize Ye_qiechu Yqiechu_size Yqiechu_size_1_10 Ytongji
    end

    % 对于单张图像进行车牌识别的代码
    %腐蚀闭运算%
    %figure;
    I1=rgb2gray(a);
    I2=edge(I1,'roberts',0.1,'both');
    se=[1;1;1];
    I3=imerode(I2,se);
    se=strel('rectangle',[30,60]);%构造结构元素以正方形构造一个se
    I4=imclose(I3,se);
    I5=bwareaopen(I4,6000);% 去除聚团灰度值小于2000的部分
    %imshow(I5)
    %-------------------------------------------------------------------------------%

    %蓝色过滤%
    red(:,:)=a(:,:,1);
    green(:,:)=a(:,:,2);
    blue(:,:)=a(:,:,3);
    siz = size(a);
    hang=siz(1);
    lie=siz(2);
    for ihang=1:hang
        for ilie=1:lie
            if blue(ihang,ilie)>=55 && red(ihang,ilie)+25<blue(ihang,ilie) && green(ihang,ilie)+25<blue(ihang,ilie)
                BluePD(ihang,ilie)=1;
            else
                BluePD(ihang,ilie)=0;
            end
        end
    end
    %figure;
    %imshow(BluePD);
    XBluePDsize=size(BluePD,1);
    YBluePDsize=size(BluePD,2);
    mess_point=floor((0.002)*(XBluePDsize*YBluePDsize));
    BluePD=bwareaopen(BluePD,mess_point); %去除小蓝色点
    %figure;
    %imshow(BluePD);
    Xfill_point=floor(0.01*(XBluePDsize));
    Yfill_point=floor(0.01*(YBluePDsize));
    se=strel('rectangle',[Xfill_point,Yfill_point]);%构造结构元素以正方形构造一个se
    BluePD=imclose(BluePD,se); %让区域更圆整，没有黑色漏洞，去除车牌号对下面统计影响
    %figure;
    %imshow(BluePD);
    %---------------------------------------------------------------------------%

    kuan=0;         %kuan初始化
    changsum=0;     %长累和初始化
    tongji_31818=[];       %3.1818统计初始化
    tongji_var=[];         %方差初始化

    kuangPD = sum(BluePD,2); %每一行白色的个数的数组
    ifind=find(kuangPD>10);  %每一行大于10点的Y坐标
    ifindsiz=size(ifind,1);  %ifind长度

    %标记每个白色Y轴终点
    ifind_1=ifind;ifind_1(end+1)=ifind(ifindsiz)+1;ifind_1(1)=[];%错一位的ifind
    Ybiaoji=ifind_1-ifind;
    Ytongji=find(Ybiaoji~=1);   %白色区域的最底部Y坐标的统计(未加最后一个底部坐标)
    Ytongji=cat(1,Ytongji,ifindsiz);%(加入最后一个)
    Tongjisiz=size(Ytongji,1);  %统计的元素个数

    %运算蓝色区域的长的方差%
    for i=1:Tongjisiz
        if i==1     %计算第一个方差
            jiequduan=kuangPD(ifind(1):ifind(Ytongji(i)));%截取第一段蓝色区域
            jiequduansiz=size(jiequduan,1);               %计算Y长度
            jiequduansiz10_1=ceil(jiequduansiz*1/10);     %Y长度的1/10
            jiequduan(1:jiequduansiz10_1)=[];             %删除白色区域顶部1/10
            jiequduansiz=size(jiequduan,1);               %更新Y长度以便索引
            jiequduan(jiequduansiz-jiequduansiz10_1:jiequduansiz)=[];%截取底部原长度Y的1/10
            tongji_var(i)=var(jiequduan);                 %计算方差，统计到数组
        else        %计算第i个方差
            jiequduan=kuangPD(ifind(Ytongji(i-1)+1):ifind( Ytongji(i) ) );%截取第i段蓝色区域
            jiequduansiz=size(jiequduan,1);               %计算Y长度
            jiequduansiz10_1=ceil(jiequduansiz*1/10);     %Y长度的1/10
            jiequduan(1:jiequduansiz10_1)=[];             %删除白色区域顶部1/10
            jiequduansiz=size(jiequduan,1);               %更新Y长度以便索引
            jiequduan(jiequduansiz-jiequduansiz10_1:jiequduansiz)=[];%截取底部原长度Y的1/10
            tongji_var(i)=var(jiequduan);                 %计算方差，统计到数组
        end
    end
    %----------------------------------------------------------------------------------------------------%


    %运算蓝色区域的长宽比%
    for i=1:Tongjisiz
        if i == 1
            %1. 将白色区域的Y坐标1/3和2/3处加起来取平均
            san_yi=floor(( ifind( Ytongji(i) ) - ifind(1) ) *(1/3)); %第一个白色区域Y坐标
            qidian=ifind(1);
            changsum=kuangPD(qidian+san_yi);                        %长度1
            san_er=floor((ifind(Ytongji(i))-ifind(1))*(2/3));
            changsum=changsum+kuangPD(qidian+san_er);%sum=长度1+长度2
            changave=changsum / 2;
            %2. 计算一个白色区域的长宽比
            ck_31818=changave / (ifind(Ytongji(i))-ifind(1)); %长宽比
            close_ck_31818= abs(ck_31818 - 3.1818);
            tongji_31818(i) = close_ck_31818; %将第tongjige个白色区域长宽比存入统计数组
            %3. 清零
            changsum = 0;
        else
            %1. 将白色区域的Y坐标1/3和2/3处加起来取平均
            san_yi=floor((ifind( Ytongji(i) ) - ifind(Ytongji(i-1)+1) ) *(1/3));
            qidian=ifind(Ytongji(i-1)+1);
            changsum=kuangPD(san_yi+qidian);
            san_er=floor( (ifind( Ytongji(i) ) - ifind(Ytongji(i-1)+1)) * (2/3));
            changsum=changsum+kuangPD(qidian+san_er);
            changave=changsum / 2;
            %2. 计算一个白色区域的长宽比
            ck_31818=changave / ( ifind(Ytongji(i)) - ifind(Ytongji(i-1)+1) ); %长宽比
            close_ck_31818= abs(ck_31818 - 3.1818); %计算差值
            tongji_31818(i) = close_ck_31818; %将第tongjige个白色区域长宽比存入统计数组
            %3. 清零
            changsum = 0;
        end
    end
    %----------------------------------------------------------------------------------------------%

    %统计每个白色区域的X坐标%
    BluePD_0=BluePD;
    BluePD_0(BluePD_0>=1)=0;    %创建一个与图片长宽相等的纯黑图片
    fushi_blue={};              %创建一个元胞数组粗存拼接的剪切白色区域

    for i=1:Tongjisiz
        if i==1 %计算第一个区域X坐标
            %从BluePD中横着剪切第一个白色区域的图像,上下涂黑%
            top_black_image= BluePD_0(1:ifind(1)-1,:);                         %取白色以上的纯黑图片
            white_image = BluePD(ifind(1):ifind(Ytongji(1)),:);                %取第一个白色区域的图像
            bottom_black_image = BluePD_0(ifind(Ytongji(i))+1:hang,:);         %取白色区域以下的纯黑图片
            guolv_image = cat(1,top_black_image,white_image,bottom_black_image);      %过滤其他白色区域的图片
            fushi_blue{1}=guolv_image;
            %-----------------------------------------------------------------%
            %压扁图片定位X坐标起始位和终止位
            X_dingwei_image=sum(guolv_image,1);     %压扁
            ifindx=find(X_dingwei_image~=0);        %保存坐标
            X_dingwei_jihe(1,1,i)=ifindx(1);
            X_dingwei_jihe(1,2,i)=ifindx(end);      %储存原图坐标
        else %计算第i个区域X坐标
            %从BluePD中横着剪切第i个白色区域的图像,上下涂黑%
            top_black_image= BluePD_0(1:ifind(Ytongji(i-1)+1)-1,:);                         %取白色以上的纯黑图片
            white_image = BluePD(ifind(Ytongji(i-1)+1):ifind(Ytongji(i)),:);                %取第i个白色区域的图像
            bottom_black_image = BluePD_0(ifind(Ytongji(i))+1:hang,:);         %取白色区域以下的纯黑图片
            guolv_image = cat(1,top_black_image,white_image,bottom_black_image);      %过滤其他白色区域的图片
            fushi_blue{i}=guolv_image;
            %-----------------------------------------------------------------%
            %压扁图片定位X坐标起始位和终止位
            X_dingwei_image=sum(guolv_image,1);     %压扁
            ifindx=find(X_dingwei_image~=0);        %保存坐标
            X_dingwei_jihe(1,1,i)=ifindx(1);
            X_dingwei_jihe(1,2,i)=ifindx(end);      %储存原图坐标
        end
    end


    %计算腐蚀车牌方法过滤区域和蓝色过滤区域重叠度%
    for i=1:Tongjisiz
        if i==1
            compare_blue=fushi_blue{i};
            compare_fushi_blue=sum(I5 & compare_blue,"all");
            tongji_compare_fs(i)=compare_fushi_blue;
        else
            compare_blue=fushi_blue{i};
            compare_fushi_blue=sum(I5 & compare_blue,"all");
            tongji_compare_fs(i)=compare_fushi_blue;
        end
    end


    %挑选最像车牌的部分%
    %       1.腐蚀车牌方法过滤区域和蓝色过滤区域的重叠度最高
    %       2.车牌是最规整的长方形,每行长度积分相等，方差最小
    %       3.长宽比最接近3.1818
    score=zeros(1,Tongjisiz);%初始化
    for i = 1:Tongjisiz
        find_fushi_blue=find(tongji_compare_fs==(max(tongji_compare_fs))); %找到最大的一个
        find_ck31818= find(tongji_31818==(min(tongji_31818))); %找到最小的一个
        find_var= find(tongji_var==(min(tongji_var)));         %找到最小的一个
        find_all=cat(2,find_fushi_blue,find_var,find_ck31818); %拼接数组
        siz_find_all=size(find_all);
        if i == find_all(1)
            score(i)=3;
            if i == find_all(2)
                score(i)=score(i)+3;
                if i == find_all(3)
                    score(i)=score(i)+1;
                end
            end
        end
    end
    suitble_area=find(score==max(score)); %最适合的是第几个白色区域

    %定位切出车牌%
    Xb_qiechu=X_dingwei_jihe(1,1,suitble_area);     %x起始坐标
    Xe_qiechu=X_dingwei_jihe(end,end,suitble_area); %x终点坐标
    %Y坐标
    if suitble_area == 1
        Yb_qiechu=ifind(1);                         %y起始坐标
        Ye_qiechu=ifind(Ytongji(suitble_area));   %y终点坐标
    else
        Yb_qiechu=ifind(Ytongji(suitble_area-1)+1);
        Ye_qiechu=ifind(Ytongji(suitble_area));
    end
    qiechu_image=I1(Yb_qiechu:Ye_qiechu,Xb_qiechu:Xe_qiechu); %定位车牌图片
    qiechu_erzhi=im2bw(qiechu_image);                         %二值化
    Xqiechu_size=size(qiechu_erzhi,2);
    Yqiechu_size=size(qiechu_erzhi,1);
    Xqiechu_size_3_100=floor(Xqiechu_size*(3/100));             %图片X的3/100
    Yqiechu_size_1_10=floor(Yqiechu_size*(15/100));             %图片Y的15/100
    %大致切割
    qiege_erzhi=qiechu_erzhi(1+Yqiechu_size_1_10:end-Yqiechu_size_1_10,1+Xqiechu_size_3_100:end-Xqiechu_size_3_100);
    mess_point=floor((Xqiechu_size*Yqiechu_size)*(0.002));
    qiege_erzhi=bwareaopen(qiege_erzhi,mess_point);
    %figure;imshow(qiege_erzhi);
    %大致定位第一个字符位置，切掉左边黑色边，以方便定位后续字符位置%
    word_size=floor(size(qiege_erzhi,2)*0.107); %一个字符的大概宽度
    word1=qiege_erzhi(:,1:word_size);           %第一个字符切割
    %figure;imshow(word1);
    word1_12=qiege_erzhi(:,1:floor(word_size*1/2));%切割第一个字符的1/2
    %figure;imshow(word1_12);
    word1PD=sum(word1_12,1);                     %压扁
    findword_0=find(word1PD==0);                 %找到左侧黑色边坐标
    if isempty(findword_0)==0                    %如果有黑色边
        qiege_erzhi=qiege_erzhi(:,findword_0(end)+1:end); %切掉黑色边
    end
    %figure;imshow(qiege_erzhi);
    %--------------------------------------------------------------------------%
    %大致定位第一个字符位置，以方便定位后续字符位置%
    %分割字符%
    word_size=floor(size(qiege_erzhi,2)*0.12); %一个字符的大概宽度
    jiangesiz=floor(size(qiege_erzhi,2)*0.02);    %计算间隔的宽度
    xiaodian=floor(size(qiege_erzhi,2)*0.082);      %小点加左右间隔宽度

    %figure;
    word1=qiege_erzhi(:,1:word_size);           %第一个字符切割
    %subplot(1,7,1);imshow(word1);
    word2=qiege_erzhi(:,word_size+jiangesiz:2*(word_size)+jiangesiz); %第二个
    %subplot(1,7,2);imshow(word2);
    word3=qiege_erzhi(:,2*(word_size)+jiangesiz+xiaodian:3*(word_size)+jiangesiz+xiaodian); %第三个
    %subplot(1,7,3);imshow(word3);
    word4=qiege_erzhi(:,3*(word_size)+2*(jiangesiz)+xiaodian:4*(word_size)+2*(jiangesiz)+xiaodian); %第四个
    %subplot(1,7,4);imshow(word4);
    word5=qiege_erzhi(:,4*(word_size)+3*(jiangesiz)+xiaodian:5*(word_size)+3*(jiangesiz)+xiaodian); %第五个
    %subplot(1,7,5);imshow(word5);
    word6=qiege_erzhi(:,5*(word_size)+4*(jiangesiz)+xiaodian:6*(word_size)+4*(jiangesiz)+xiaodian); %第六个
    %subplot(1,7,6);imshow(word6);
    word7=qiege_erzhi(:,6*(word_size)+5*(jiangesiz)+xiaodian:end); %第七个
    %subplot(1,7,7);imshow(word7);

    %根据百分比大致切割的字符不是很规整，对字符两边的黑色区域进行切割，以增加准确率%
    %------------------------------------------------------------字符1
    word_=sum(word1,1);                        %压扁图片
    word1_siz=size(word_,2);
    word1_14siz=floor(word1_siz/4);
    left_word1=word_(1:+word1_14siz);          %左1/4
    find_leftblack=find(left_word1==0);         %左侧黑色坐标
    right_word1=flip(word_(end-word1_14siz:end));    %右1/4
    find_rightblack=find(right_word1==0);       %右侧黑色坐标
    if isempty(find_leftblack)==0 && isempty(find_rightblack)==0    %两侧有黑边
        word1=word1(:,find_leftblack(end):end-find_rightblack(end));
    else if isempty(find_leftblack)==0                              %只有左侧有黑边
            word1=word1(:,find_leftblack(end):end);
    else if isempty(find_rightblack)==0                             %只有右侧有黑边
            word1=word1(:,1:end-find_rightblack(end));
    end
    end
    end
    %------------------------------------------------------------字符2
    word_=sum(word2,1);                        %压扁图片
    word1_siz=size(word_,2);
    word1_14siz=floor(word1_siz/4);
    left_word1=word_(1:+word1_14siz);          %左1/4
    find_leftblack=find(left_word1==0);         %左侧黑色坐标
    right_word1=flip(word_(end-word1_14siz:end));    %右1/4
    find_rightblack=find(right_word1==0);       %右侧黑色坐标
    if isempty(find_leftblack)==0 && isempty(find_rightblack)==0    %两侧有黑边
        word2=word2(:,find_leftblack(end):end-find_rightblack(end));
    else if isempty(find_leftblack)==0                              %只有左侧有黑边
            word2=word2(:,find_leftblack(end):end);
    else if isempty(find_rightblack)==0                             %只有右侧有黑边
            word2=word2(:,1:end-find_rightblack(end));
    end
    end
    end
    %------------------------------------------------------------字符3
    word_=sum(word3,1);                        %压扁图片
    word1_siz=size(word_,2);
    word1_14siz=floor(word1_siz/4);
    left_word1=word_(1:+word1_14siz);          %左1/4
    find_leftblack=find(left_word1==0);         %左侧黑色坐标
    right_word1=flip(word_(end-word1_14siz:end));    %右1/4
    find_rightblack=find(right_word1==0);       %右侧黑色坐标
    if isempty(find_leftblack)==0 && isempty(find_rightblack)==0    %两侧有黑边
        word3=word3(:,find_leftblack(end):end-find_rightblack(end));
    else if isempty(find_leftblack)==0                              %只有左侧有黑边
            word3=word3(:,find_leftblack(end):end);
    else if isempty(find_rightblack)==0                             %只有右侧有黑边
            word3=word3(:,1:end-find_rightblack(end));
    end
    end
    end
    %------------------------------------------------------------字符4
    word_=sum(word4,1);                        %压扁图片
    word1_siz=size(word_,2);
    word1_14siz=floor(word1_siz/4);
    left_word1=word_(1:+word1_14siz);          %左1/4
    find_leftblack=find(left_word1==0);         %左侧黑色坐标
    right_word1=flip(word_(end-word1_14siz:end));    %右1/4
    find_rightblack=find(right_word1==0);       %右侧黑色坐标
    if isempty(find_leftblack)==0 && isempty(find_rightblack)==0    %两侧有黑边
        word4=word4(:,find_leftblack(end):end-find_rightblack(end));
    else if isempty(find_leftblack)==0                              %只有左侧有黑边
            word4=word4(:,find_leftblack(end):end);
    else if isempty(find_rightblack)==0                             %只有右侧有黑边
            word4=word4(:,1:end-find_rightblack(end));
    end
    end
    end
    %------------------------------------------------------------字符5
    word_=sum(word5,1);                        %压扁图片
    word1_siz=size(word_,2);
    word1_14siz=floor(word1_siz/4);
    left_word1=word_(1:+word1_14siz);          %左1/4
    find_leftblack=find(left_word1==0);         %左侧黑色坐标
    right_word1=flip(word_(end-word1_14siz:end));    %右1/4
    find_rightblack=find(right_word1==0);       %右侧黑色坐标
    if isempty(find_leftblack)==0 && isempty(find_rightblack)==0    %两侧有黑边
        word5=word5(:,find_leftblack(end):end-find_rightblack(end));
    else if isempty(find_leftblack)==0                              %只有左侧有黑边
            word5=word5(:,find_leftblack(end):end);
    else if isempty(find_rightblack)==0                             %只有右侧有黑边
            word5=word5(:,1:end-find_rightblack(end));
    end
    end
    end
    %------------------------------------------------------------字符6
    word_=sum(word6,1);                        %压扁图片
    word1_siz=size(word_,2);
    word1_14siz=floor(word1_siz/4);
    left_word1=word_(1:+word1_14siz);          %左1/4
    find_leftblack=find(left_word1==0);         %左侧黑色坐标
    right_word1=flip(word_(end-word1_14siz:end));    %右1/4
    find_rightblack=find(right_word1==0);       %右侧黑色坐标
    if isempty(find_leftblack)==0 && isempty(find_rightblack)==0    %两侧有黑边
        word6=word6(:,find_leftblack(end):end-find_rightblack(end));
    else if isempty(find_leftblack)==0                              %只有左侧有黑边
            word6=word6(:,find_leftblack(end):end);
    else if isempty(find_rightblack)==0                             %只有右侧有黑边
            word6=word6(:,1:end-find_rightblack(end));
    end
    end
    end
    %------------------------------------------------------------字符7
    word_=sum(word7,1);                        %压扁图片
    word1_siz=size(word_,2);
    word1_14siz=floor(word1_siz/4);
    left_word1=word_(1:+word1_14siz);          %左1/4
    find_leftblack=find(left_word1==0);         %左侧黑色坐标
    right_word1=flip(word_(end-word1_14siz:end));    %右1/4
    find_rightblack=find(right_word1==0);       %右侧黑色坐标
    if isempty(find_leftblack)==0 && isempty(find_rightblack)==0    %两侧有黑边
        word7=word7(:,find_leftblack(end):end-find_rightblack(end));
    else if isempty(find_leftblack)==0                              %只有左侧有黑边
            word7=word7(:,find_leftblack(end):end);
    else if isempty(find_rightblack)==0                             %只有右侧有黑边
            word7=word7(:,1:end-find_rightblack(end));
    end
    end
    end


    %归一化大小为 40*20
    word1=imresize(word1,[40 20]);
    word2=imresize(word2,[40 20]);
    word3=imresize(word3,[40 20]);
    word4=imresize(word4,[40 20]);
    word5=imresize(word5,[40 20]);
    word6=imresize(word6,[40 20]);
    word7=imresize(word7,[40 20]);
    % figure;
    % subplot(1,7,1);imshow(word1);
    % subplot(1,7,2);imshow(word2);
    % subplot(1,7,3);imshow(word3);
    % subplot(1,7,4);imshow(word4);
    % subplot(1,7,5);imshow(word5);
    % subplot(1,7,6);imshow(word6);
    % subplot(1,7,7);imshow(word7);
    %将切割下来短的字符保存为图片
    imwrite(word1,'1.jpg');
    imwrite(word2,'2.jpg');
    imwrite(word3,'3.jpg');
    imwrite(word4,'4.jpg');
    imwrite(word5,'5.jpg');
    imwrite(word6,'6.jpg');
    imwrite(word7,'7.jpg');

    %%%%字符识别%%%%
    %建立自动识别字符代码表
    liccode=char(['0':'9' 'A':'H' 'J':'N' 'P':'Z' '藏川鄂甘赣桂贵黑沪吉冀津晋京辽鲁蒙闽宁青琼陕苏皖湘新渝豫粤云浙']);  %建立自动识别字符代码表
    l=1;
    for I=1:7
        ii=int2str(I);%将整形变成字符串
        t=imread([ii,'.jpg']);
        SegBw2=imresize(t,[40 20],'nearest');

        if l==1                 %第一位汉字识别
            kmin=35;
            kmax=65;
        elseif l==2             %第二位 A~Z 字母识别
            kmin=11;
            kmax=34;
        else l>=3;               %第三位以后是字母或数字识别
            kmin=1;
            kmax=34;

        end

        %在每一位对应区间按顺序提取字符模板
        for k2=kmin:kmax
            fname=strcat('字符模板',liccode(k2),'.jpg');
            SamBw2 = imread(fname);
            if(k2~=2)
                SamBw2=rgb2gray(SamBw2);
            end
            g_max=double(max(max(SamBw2)));%二值化处理字符模板
            g_min=double(min(min(SamBw2)));
            T=round(g_max-(g_max-g_min)/2); % T为二值化的阈值
            SamBw2=(double(SamBw2)>=T);  % SamBw2为字符模板的二值图像

            %字符图像与模板进行比较
            a1(k2)=corr2(SegBw2,SamBw2);
        end

        A1=a1(kmin:kmax);%将比较结果放入矩阵A1
        MaxA1=max(A1);%找到比较结果最大值
        findc=find(A1==MaxA1);%获取最大值所在位置
        if isempty(findc)==1
            Code(l*2-1)= liccode(1);
        else
            Code(l*2-1)=liccode(findc(1)+kmin-1);
            Code(l*2)=' ';
            l=l+1;%进行下一字符的提取和比较
        end
    end

    figure(1),subplot(2,7,1:7),
    imshow(qiege_erzhi),title('车牌定位结果'),
    xlabel(['识别结果为: ', Code]);

    name=strtok(name,'.');%截取图像名，与识别的车牌进行比较
    Code = regexprep(char(Code), ' ', '');%去除空格
    fid=fopen(['C:\Users\45094\Desktop\Chepai\','1.txt'],'a+');% 写入文件路径
    fprintf(fid,'文件名：%s\t\t识别名字：%s',name,Code);
    if strcmp(Code,name)==1
        tot=tot+1;%对的个数
        fprintf(fid,' \t匹配成功!!!\r\n');
    else
        tot=tot;%错的个数
        fprintf(fid,' \t匹配失败...\r\n');
    end
end
everage=(tot/len)*100;%平均数
fprintf(fid,'识别正确率：%d/%d=%.2f%%\r\n',tot,len,everage);
fclose(fid);
msg = ['正确率为:', num2str(everage), '%'];
msgbox(msg, '提示');
