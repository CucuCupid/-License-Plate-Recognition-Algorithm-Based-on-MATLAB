global Code;
global dw;
global tot;
tot=0;

pn='D:\desktopFile-self\digital image processing\endtest\inputPicture\';
namelist = dir(strcat(pn,'*.jpg'));  %获得文件夹下所有的 .jpg图片
len = length(namelist);%当前文件的图片个数
for i=1:len
    name=namelist(i).name; %输入原始图像
    Imagine=imread([pn name]);%输入原始图像

%%%%根据hsv色彩定位法定位车牌%%%%
Image=im2double(Imagine); %把图像数据类型转换为double类型 
Image=rgb2hsv(Image); %将RGB图像转化为hsv模型，H色相，S饱和度，V亮度 
[y,x,~]=size(Image);  
Blue_y = zeros(y, 1);  
p=[0.56 0.71 0.4 1 0.3 1 0];  
for i = 1 : y  
    for j = 1 : x  
        hij = Image(i, j, 1);  %取出每个像素点的H、S、V值
        sij = Image(i, j, 2);  
        vij = Image(i, j, 3);  
        if (hij>=p(1) && hij<=p(2)) &&( sij >=p(3)&& sij<=p(4))&&(vij>=p(5)&&vij<=p(6)) %若像素点的HSV处于蓝色的HSV范围 
            Blue_y(i, 1) = Blue_y(i, 1) + 1;%统计每行的蓝色像素点数目   
        end  
    end  
end  
[~, MaxY] = max(Blue_y);%获取蓝色像素点最多的行号 
Th = p(7); %Th=0 
PY1 = MaxY;  
while ((Blue_y(PY1,1)>Th) && (PY1>0))%找到车牌上边界  
    PY1 = PY1 - 1;  
end  
PY2 = MaxY;  
while ((Blue_y(PY2,1)>Th) && (PY2<y))%找到车牌下边界
    PY2 = PY2 + 1;  
end  
PY1 = PY1 - 2; %上下边界校正（扩大） 
PY2 = PY2 + 2;  
if PY1 < 1  %如果图像内容只有车牌，上述校正可能会使得边界值超出合理范围，此处防止边界值超出图像范围
    PY1 = 1;  
end  
if PY2 > y  
    PY2 = y;  
end  
It=Imagine(PY1:PY2,:,:);%Y方向获取原图的车牌区域  
%figure(2),subplot(3,1,1),imshow(It),title('hsv色彩分割法进行车牌行定位结果');
IY = Image(PY1:PY2, :, :); %对HSV模型图像Image在Y方向进行截取 
[y1,x1,z1]=size(IY);  
Blue_x=zeros(1,x1);  
for j = 1 : x1  
    for i = 1 : y1  
        hij = IY(i, j, 1); %获取每个像素点的HSV 
        sij = IY(i, j, 2);  
        vij = IY(i, j, 3);  
        if (hij>=p(1) && hij<=p(2)) &&( sij >=p(3)&& sij<=p(4))&&(vij>=p(5)&&vij<=p(6))%若为蓝色像素点  
            Blue_x(1, j) = Blue_x(1, j) + 1;   %记录每一列蓝色像素数目
        end  
    end  
end  
  
PX1=1;PX2=x1;%找到左右边界
while Blue_x(1, PX1)==0
    PX1=PX1+1;
end
while Blue_x(1, PX2)==0
    PX2=PX2-1;
end

I1=Imagine(PY1:PY2,PX1:PX2,:);%车牌剪裁  
%figure(2),subplot(3,1,2),imshow(I1),title('hsv色彩分割法车牌定位结果');
I2=rgb2gray(I1);                        


%%%%字符分割前的图像处理%%%%
%边界校正
[y,x,z]=size(I2);%I2有y行x列
PX1=round(x*5/440);%根据实际车牌比例，将边框部分去除
PX2=x-round(x*5/440);
PY1=round(y*16/140);
PY2=y-round(y*16/140);
fprintf('校正后  左边界=%d、右边界=%d、上边界=%d、下边界=%d',PX1,PX2,PY1,PY2);
%彩色图像车牌部分截取
dw=I1(PY1:PY2,PX1:PX2,:);%对边界进行截取
%figure(2),subplot(3,1,3),imshow(dw),title('边界校正结果');
imwrite(dw,'dw.jpg');%把截取后的彩色图像新创建一张图片，命名为dw
a=imread('dw.jpg');
b=rgb2gray(a);
imwrite(b,'1.车牌灰度图像.jpg');
g_max=double(max(max(b)));%得出剪裁后灰度图矩阵的最大值，并变成双精度浮点型
g_min=double(min(min(b)));%得出剪裁后灰度图矩阵的最小值，并变成双精度浮点型
T=round(g_max-(g_max-g_min)/2); % T为二值化的阈值，round用于取整
d=(double(b)>=T);  % d:二值图像
imwrite(d,'2.车牌二值图像.jpg');
%figure(3),subplot(3,1,1),imshow(d),title('二值图像');
 
% 滤波
h=fspecial('average',3);%创建一个二维滤波器，average是类型，3是参数
d=im2bw(round(filter2(h,d)));%filter2进行滤波处理，im2bw使用阈值变换法把灰度图像转换成二值图像
imwrite(d,'4.均值滤波后.jpg');

%去点处理
d=cut(d);
[m,n]=size(d);
d(:,round(n*122/430):round(n*137/430))=0;%去除中间的点
d=bwareaopen(d,65);%用于删除二值图像中面积小于一个定值（此处为65）的对象，默认情况下使用8邻域
%figure(3),subplot(3,1,2),imshow(d),title('去点处理');

%上下边框处理，找到上下边界处像素值小于20的行，并将整行设为零
s=zeros(1,m);
i=1;
while i<=m
    s(i)=sum(d(i,:));
    i=i+1;
end
j=0;c=zeros(1,m);%c矩阵用于记录下边框处像素值小于20的行，用于确定边框与字符间空隙的位置
while j<m
    while s(j+1)>20&&j<m-1
        j=j+1;
    end
    if j<round(m*12/140) %如果是上边框
        d((1:j),:)=0;
    else j>round(m*115/140)%如果是下边框
        c(j)=j;%将下边界处理中像素值小于20的行记录下来
        d(j,:)=0;
    end
    j=j+1;
end
jj=round(m/2);%这里是为了找到下边界处理中，被记录下来的最小行（即边框和字符间空隙的上沿），所以从中间开始往下找，直到找到的第一个非零数
while c(jj)==0
      jj=jj+1;
end
d((jj:m),:)=0;%将这一行以下皆设为0
d=cut(d);
%figure(3),subplot(3,1,3),imshow(d),title('上下边框处理');
imwrite(d,'5.切割前.jpg');
%%%%字符分割%%%%
[~,n]=size(d);
% 切割出 7 个字符
% 第一个字符，
y1=n*15/440;y2=0.25;flag=0;word1=[];
while flag==0
    [m,~]=size(d);
    left=1;wide=0;
    while sum(d(:,wide+1))~=0 % 找到像素和为零的列
        wide=wide+1;
    end
    if wide<y1   % 若这一列的位置在图像左侧前10列之内则认为是左侧干扰
        d(:,(1:wide))=0;%把左侧干扰全部变为0，并将其切割掉
        d=cut(d);
    else
        temp=cut(imcrop(d,[1 1 wide m]));%将一个字符剪切下来
        [m,~]=size(temp);
        all=sum(sum(temp));%第一个字符的像素值总和
        two_thirds=sum(sum(temp((round(m/3):2*round(m/3)),:)));%单个字符中段1/3图像的像素值总和
        if two_thirds/all>y2%验证是否为字符
            flag=1;word1=temp;   %获取第一个字符word1
        end
        d(:,(1:wide))=0;d=cut(d);%当提取第一个字符结束或者不满足上述条件时，将该区域变为0，并切除
    end
end

% 分割出第二个字符
[word2,d]=extract(d);
% 分割出第三个字符
[word3,d]=extract(d);
% 分割出第四个字符
[word4,d]=extract(d);
% 分割出第五个字符
[word5,d]=extract(d);
% 分割出第六个字符
[word6,d]=extract(d);
% 分割出第七个字符
[word7,d]=extract(d);
[m,n]=size(word1);
 
%归一化大小为 40*20
word1=imresize(word1,[40 20]);
word2=imresize(word2,[40 20]);
word3=imresize(word3,[40 20]);
word4=imresize(word4,[40 20]);
word5=imresize(word5,[40 20]);
word6=imresize(word6,[40 20]);
word7=imresize(word7,[40 20]);
%将切割下来短的字符保存为图片
imwrite(word1,'1.jpg');
imwrite(word2,'2.jpg');
imwrite(word3,'3.jpg');
imwrite(word4,'4.jpg');
imwrite(word5,'5.jpg');
imwrite(word6,'6.jpg');
imwrite(word7,'7.jpg');


%%%%字符识别%%%%
%建立自动识别字符代码表  
liccode=char(['0':'9' 'A':'H' 'J':'N' 'P':'Z' '藏川鄂甘赣桂贵黑沪吉冀津晋京辽鲁蒙闽宁青琼陕苏皖湘新渝豫粤云浙']);  %建立自动识别字符代码表  
SubBw2=zeros(40,20);
l=1;
for I=1:7
    ii=int2str(I);%将整形变成字符串
     t=imread([ii,'.jpg']);
      SegBw2=imresize(t,[40 20],'nearest');
      %进行二值化，方便比较
      g_max=double(max(max(SegBw2)));
      g_min=double(min(min(SegBw2)));
      T=round(g_max-(g_max-g_min)/2); % T为二值化的阈值
      SegBw2=(double(SegBw2)>=T);  % SegBw2切割下来的字符的二值图像
      
        if l==1                 %第一位汉字识别
            kmin=35;
            kmax=65;
        elseif l==2             %第二位 A~Z 字母识别
            kmin=11;
            kmax=34;
        else l>=3;               %第三位以后是字母或数字识别
            kmin=1;
            kmax=34;
        
        end
        
        %在每一位对应区间按顺序提取字符模板
        for k2=kmin:kmax
            fname=strcat('字符模板',liccode(k2),'.jpg');
            SamBw2 = imread(fname);
            if(k2~=2)
                SamBw2=rgb2gray(SamBw2);
            end
            g_max=double(max(max(SamBw2)));%二值化处理字符模板
            g_min=double(min(min(SamBw2)));
            T=round(g_max-(g_max-g_min)/2); % T为二值化的阈值
            SamBw2=(double(SamBw2)>=T);  % SamBw2为字符模板的二值图像
            
            %字符图像与模板进行比较
            a1(k2)=corr2(SegBw2,SamBw2);
        end
        
        A1=a1(kmin:kmax);%将比较结果放入矩阵A1
        MaxA1=max(A1);%找到比较结果最大值
        findc=find(A1==MaxA1);%获取最大值所在位置
        Code(l*2-1)=liccode(findc(1)+kmin-1);
        Code(l*2)=' ';
        l=l+1;%进行下一字符的提取和比较
end
    figure(4),subplot(2,7,1:7),imshow(dw),title('车牌定位结果'),
    xlabel(['识别结果为: ', Code]);


    name=strtok(name,'.');%截取图像名，与识别的车牌进行比较
    Code = regexprep(char(Code), ' ', '');%去除空格
    %           D:\desktopFile-self\digital image processing\endtest\inputPicture\
    fid=fopen(['D:\desktopFile-self\digital image processing\endtest\','1.txt'],'a+');% 写入文件路径
    fprintf(fid,'文件名：%s\t\t识别名字：%s',name,Code);
    if strcmp(Code,name)==1
        tot=tot+1;%对的个数
        fprintf(fid,' \t匹配成功!!!\r\n');
    else
        tot=tot;%错的个数
        fprintf(fid,' \t匹配失败...\r\n');
    end
     
end
everage=(tot/len)*100;%平均数
fprintf(fid,'识别正确率：%d/%d=%.2f%%\r\n',tot,len,everage);
fclose(fid);
 
